﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WE_DivaSponsor.Controllers
{
    public class SponsorRegistrationController : Controller
    {
        //
        // GET: /SponsorRegistration/



        

        public ActionResult SponsorRegistrationview()
        {
            return View();
        }

        public int SponsorRegistration(string fname, string lname, string age, string dob, string product, string aadharid, string mobile, string occupation, string address, string amount, string cardholdername, string cardnumber, string cvc, string expirydt)
        {
            DateTime dt;
            if (DateTime.TryParseExact(dob, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out dt))
            {
                dob = dt.ToString("MM/dd/yyyy");
            }
            SqlConnection con = new SqlConnection("Data Source=MININT-O5CMQBM;Initial Catalog=WE_Sponsor;User ID=sa;Password=Welcome@123;");
            con.Open();
            //SqlCommand cmd = new SqlCommand("insert into SponsorRegistration (Firstname,Lastname,DOB,Age,Occupation,Mobileno,AadharId,Address,Productname,Sponsoramount,Cardholdername,Cardnumber,Expirydate,CVC)values(@fname,@lname,@dob,@age,@product,@aadharid,@mobile,@occupation,@address,@amount,@cardholdername,@cardnumber,@expirydt,@cvc)", con);
            //cmd.Parameters.AddWithValue("@fname", fname);
            //cmd.Parameters.AddWithValue("@lname", lname);
            //cmd.Parameters.AddWithValue("@dob", dob);
            //cmd.Parameters.AddWithValue("@age", int.Parse(age));
            //cmd.Parameters.AddWithValue("@occupation", occupation);
            //cmd.Parameters.AddWithValue("@mobile", long.Parse(mobile));           
            //cmd.Parameters.AddWithValue("@aadharid",long.Parse(aadharid));
            //cmd.Parameters.AddWithValue("@product", product);
            //cmd.Parameters.AddWithValue("@address", address);
            //cmd.Parameters.AddWithValue("@amount", int.Parse(amount));
            //cmd.Parameters.AddWithValue("@cardholdername", cardholdername);
            //cmd.Parameters.AddWithValue("@cardnumber", long.Parse(cardnumber));
            //cmd.Parameters.AddWithValue("@cvc", int.Parse(cvc));
            //cmd.Parameters.AddWithValue("@expirydt", expirydt);
            //int result = cmd.ExecuteNonQuery();

            SqlCommand cmd = new SqlCommand("UDP_Sponsorinsert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@firstname", fname);
            cmd.Parameters.AddWithValue("@lastname", lname);
            cmd.Parameters.AddWithValue("@dOB", dob);
            cmd.Parameters.AddWithValue("@age", int.Parse(age));
            cmd.Parameters.AddWithValue("@occupation", occupation);
            cmd.Parameters.AddWithValue("@mobileno", long.Parse(mobile));
            cmd.Parameters.AddWithValue("@aadharId", long.Parse(aadharid));
            cmd.Parameters.AddWithValue("@productname", product);
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@sponsoramount", int.Parse(amount));
            cmd.Parameters.AddWithValue("@cardholdername", cardholdername);
            cmd.Parameters.AddWithValue("@cardnumber", long.Parse(cardnumber));
            cmd.Parameters.AddWithValue("@cVC", int.Parse(cvc));
            cmd.Parameters.AddWithValue("@expirydate", expirydt);
            int result = cmd.ExecuteNonQuery();
            return result;
        }
    }
}
