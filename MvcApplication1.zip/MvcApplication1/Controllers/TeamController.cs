﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication1.Controllers
{
    public class TeamController : Controller
    {
        //
        // GET: /Team/
        string cs = "Data Source=DS-A101AA300454\\SQLEXPRESS;Initial Catalog=TeamRegistation;User ID=sa;Password=Welcome@123";

        public ActionResult Index()
        {
            return View();

        }
        public int JavaScriptTeam(string TeamName, string EFName, string Elname, string DOB, string Age, string Addres, string PhoneNumber, string APNumber, string AdharId, string FSName, string AccNumber, string IFCS, string ProductId)
        {
            DateTime dt;
            if(DateTime.TryParseExact(DOB,"yyyy-MM-dd",null,System.Globalization.DateTimeStyles.None,out dt))
            {
                DOB = dt.ToString("MM-dd-yyyy");
            }
            //SqlConnection con = new SqlConnection(cs);
            //con.Open();
            //SqlCommand cmd = new SqlCommand(" insert into TeamRegistation(TeamName,EFName,Elname,DOB,Age,Addres,PhoneNumber,APNumber,AdharId,FSName,AccNumber,IFCS,ProductId)values(@Teamname,@EFName,@Elname,@DOB,@Age,@Addres,@PhoneNumber,@APNumber,@AdharId,@FSName,@AccNumber,@IFCS,@ProductId)", con);
            //cmd.Parameters.AddWithValue("@TeamName", TeamName);
            //cmd.Parameters.AddWithValue("@EFName", EFName);
            //cmd.Parameters.AddWithValue("@Elname", Elname);
            //cmd.Parameters.AddWithValue("@DOB", DOB);
            //cmd.Parameters.AddWithValue("@Age", int.Parse(Age));
            //cmd.Parameters.AddWithValue("@Addres", Addres);
            //cmd.Parameters.AddWithValue("@PhoneNumber", long.Parse(PhoneNumber));
            //cmd.Parameters.AddWithValue("@APNumber", long.Parse(APNumber));
            //cmd.Parameters.AddWithValue("@AdharId", long.Parse(AdharId));
            //cmd.Parameters.AddWithValue("@FSName", FSName);
            //cmd.Parameters.AddWithValue("@AccNumber", long.Parse(AccNumber));
            //cmd.Parameters.AddWithValue("@IFCS", long.Parse(IFCS));
            //cmd.Parameters.AddWithValue("@ProductId", ProductId);
            //int result = cmd.ExecuteNonQuery();
            //return result;
           

            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("UDP_InsertTeam", con);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.AddWithValue("@TeamName", TeamName);
            cmd.Parameters.AddWithValue("@EFName", EFName);
            cmd.Parameters.AddWithValue("@Elname", Elname);
            cmd.Parameters.AddWithValue("@DOB", DOB);
            cmd.Parameters.AddWithValue("@Age", int.Parse(Age));
            cmd.Parameters.AddWithValue("@Addres", Addres);
            cmd.Parameters.AddWithValue("@PhoneNumber", long.Parse(PhoneNumber));
            cmd.Parameters.AddWithValue("@APNumber", long.Parse(APNumber));
            cmd.Parameters.AddWithValue("@AdharId", long.Parse(AdharId));
            cmd.Parameters.AddWithValue("@FSName", FSName);
            cmd.Parameters.AddWithValue("@AccNumber", long.Parse(AccNumber));
            cmd.Parameters.AddWithValue("@IFCS", long.Parse(IFCS));
            cmd.Parameters.AddWithValue("@ProductId", ProductId);
            int result = cmd.ExecuteNonQuery();
            return result;

            








        }

    }
}
  
  