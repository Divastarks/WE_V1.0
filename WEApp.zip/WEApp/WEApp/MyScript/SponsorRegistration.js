﻿$(document).ready(function () {
    $("#submit").click(function () {
        var fname = $("#firstname").val();
        var lname = $("#lastname").val();
        var age = $("#age").val();
        var dob = $("#dob").val();
        var product = $("#product").val();
        var aadharid = $("#aadhar").val();
        var mobile = $("#mobile").val();
        var occupation = $("#occupation").val();
        var address = $("#address").val();
        var amount = $("#amount").val();
        var cardholdername = $("#cardholdername").val();
        var cardnumber = $("#cardnumber").val();
        var cvc = $("#cvc").val();
        var expirydt = $("#expirydt").val();
//alert(fname + " " + lname + " " + age + " " + dob + " " + product + " " + aadharid + " " + mobile + " " + occupation + " " + address + " " + amount + " " + cardholdername + " " + cardnumber + " " + cvc + " " + expirydt + " ");

        $.ajax({
            url: '/SponsorRegistration/SponsorRegistration',
            async: false,
            type: 'GET',
            data: {"fname":fname,"lname":lname,"age":age,"dob":dob,"product":product,"aadharid":aadharid,"mobile":mobile,"occupation":occupation,"address":address,"amount":amount,"cardholdername":cardholdername,"cardnumber":cardnumber,"cvc":cvc,"expirydt":expirydt},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Registration Done");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));
            }
        });

    });
});