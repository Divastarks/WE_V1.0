﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WEApp.Controllers
{
    public class TeamController : Controller
    {
        //
        // GET: /Team/

        public ActionResult TeamRegistration()
        {
            return View();
        }
        public ActionResult ProductUpdateForm()
        {
            return View();
        }

    }
}
