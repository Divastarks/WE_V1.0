﻿$(document).ready(function () {
    $("#register").click(function(){
        var TeamName=$("#TeamName").val();
        var EFName=$("#EFName").val();
        var Elname=$("#Elname").val();
        var DOB=$("#DOB").val();
        var Age=$("#Age").val();
        var Addres=$("#Addres").val();
        var PhoneNumber=$("#PhoneNumber").val();
        var APNumber=$("#APNumber").val();
        var AdharId=$("#AdharId").val();
        var FSName=$("#FSName").val();
        var AccNumber=$("#AccNumber").val();
        var IFCS=$("#IFCS").val();
        var ProductId=$("#ProductId").val();
  
        //alert(TeamName + " " + EFName + " " + Elname + " " + DOB + " " + Age + " " + Addres + " " + PhoneNumber + " " + APNumber + " " + AdharId + " " + FSName + " " + AccNumber + " " + IFCS + " " + ProductId);

        $.ajax({
            url: '/Team/JavaScriptTeam',
            async: false,
            type: 'Get',
            data:{"TeamName":TeamName,"EFName":EFName,"Elname":Elname,"DOB":DOB,"Age":Age,"Addres":Addres,"PhoneNumber":PhoneNumber,"APNumber":APNumber,"AdharId":AdharId,"FSName":FSName,"AccNumber":AccNumber,"IFCS":IFCS,"ProductId":ProductId},
            dataType:'json',
        contentType: 'application/json;charset=utf-8',
        success: function (data)
        {
            alert("Registration done");
        },
        error: function(request,error)
        {
            alert("request:"+JSON.stringify(request));
        }


    });
});

});