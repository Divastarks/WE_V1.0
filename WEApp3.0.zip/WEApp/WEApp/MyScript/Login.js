﻿$(document).ready(function () {
    $("#btnlogin").click(function () {

        var username = $("#UserName").val();

        var Password = $("#Password").val();

        //alert(username + "\n" + Password );
        $.ajax({
            url: '/Home/Sigin',
            async: false,
            type: 'GET',
            data: { "username": username, "password": Password },
            dataType: 'json',
            contentType: 'appllication/json;charset=utf-8',
            success: function (data) {
                if (data > 0) 
                    window.location.href = "/Home/Dashboard";
                else              
                    $("#lblerror").text("Invalid UserName or Password");
                
            },
            error: function (request, error) {
                alert("Request" + JSON.stringify(request));
            }
        });
    });
});