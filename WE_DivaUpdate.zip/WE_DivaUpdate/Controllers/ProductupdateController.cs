﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WE_DivaUpdate.Controllers
{
    public class ProductupdateController : Controller
    {
        //
        // GET: /Productupdate/

        public ActionResult Update()
        {
            return View();
        }
        string cs = " Data Source=DS-B101AA353077\\SQLEXPRESS;Initial Catalog=ProductUpdate;User ID=sa;Password=Welcome@123";


        public int Updatee(string Stock, string ProductDescription, string Mobilenumber, string EmailID, string ProductName, string TeamID)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into ProductUpdate(Stock,ProductDescription,Mobilenumber,EmailID,ProductName,TeamID )values(@Stock,@ProductDescription,@Mobilenumber,@EmailID,@ProductName,@TeamID)", con);

            cmd.Parameters.AddWithValue("@Stock", int.Parse(Stock));
            cmd.Parameters.AddWithValue("@ProductDescription", ProductDescription);
            cmd.Parameters.AddWithValue("@Mobilenumber", int.Parse(Mobilenumber));
            cmd.Parameters.AddWithValue("@EmailID", EmailID);
            cmd.Parameters.AddWithValue("@ProductName", ProductName);
            cmd.Parameters.AddWithValue("@TeamID", int.Parse(TeamID));
            int result = cmd.ExecuteNonQuery();
            return result;
        }
    }
}