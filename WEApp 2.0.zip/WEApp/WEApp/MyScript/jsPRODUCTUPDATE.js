﻿$(document).ready(function () {
    $("#btnsubmit").click(function () {
        var Stock = $("#Stock").val();
        var ProductDescription = $("#ProductDescription").val();
        var Mobilenumber = $("#Mobilenumber").val();
        var EmailID = $("#EmailID").val();
        var ProductName = $("#ProductName option:selected").val();
        var TeamID = $("#TeamID").val();

        //alert(TeamID + " " + ProductName + " " + ProductDescription+" " +Stock+  " " + Mobilenumber + " " + EmailID );

        $.ajax({
            url: '/ProductUpdate/Updatee',
            async: false,
            type: 'GET',
            data: { "Stock": Stock, "ProductDescription": ProductDescription, "Mobilenumber": Mobilenumber, "EmailID": EmailID, "ProductName": ProductName, "TeamID": TeamID },
            datatype: 'JSON',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Updation done!!");

            },
            error: function (request, error) {
                alert("Request:" + JSON.stringify(request));
            }
        });

    });
});