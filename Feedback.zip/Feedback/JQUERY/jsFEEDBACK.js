﻿$(document).ready(function () {
    $("#btnsubmit").click(function () {
        var username = $("#username").val();
        var FeedBackRating = $("input[name='rating']:checked").val();
        var comments = $("#comments").val();

         alert(username+" "+FeedBackRating+" "+comments);

        $.ajax({
            url: '/Feedback/comments',
            async: false,
            type:'GET',
            data: { "username": username, "comments": comments, "FeedBackRating": FeedBackRating },
            datatype:'JSON',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Registration done!!");

            },
            error: function (request, error) {
                alert("Request:" + JSON.stringify(request));
            }
        });

    });
});