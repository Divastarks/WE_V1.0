﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Feedback.Controllers
{
    public class ProductUpdateController : Controller
    {
        //
        // GET: /ProductUpdate/

        string cs = " Data Source=DS-B101AA353077\\SQLEXPRESS;Initial Catalog= ProductUpdate;User ID=sa;Password=Welcome@123";


        public ActionResult Index()
        {
            return View();
        }
        public int Update(string Stock, string ProductDescription, string Mobilenumber, string EmailID, string ProductID, string TeamID)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into ProductUpdate(Stock,ProductDescription,Mobilenumber,EmailID,ProductID,TeamID )values(@Stock,@ProductDescription,@Mobilenumber,@EmailID,@ProductID,@TeamID)", con);

            cmd.Parameters.AddWithValue("@Stock", int.Parse(Stock));
            cmd.Parameters.AddWithValue("@ProductDescription", ProductDescription);
            cmd.Parameters.AddWithValue("@Mobilenumber", int.Parse(Mobilenumber));
            cmd.Parameters.AddWithValue("@EmailID", EmailID);
            cmd.Parameters.AddWithValue("@ProductID", int.Parse(ProductID));
            cmd.Parameters.AddWithValue("@TeamID", int.Parse(TeamID));
            int result = cmd.ExecuteNonQuery();
            return result;
        }

        
    }
}


