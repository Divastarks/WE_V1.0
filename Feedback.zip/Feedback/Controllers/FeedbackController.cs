﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Feedback.Controllers
{
    public class FeedbackController : Controller
    {
        //
        // GET: /Feedback/
        
       string cs = " Data Source=DS-B101AA353077\\SQLEXPRESS;Initial Catalog=Feedbackform;User ID=sa;Password=Welcome@123";

        public ActionResult Index()
        {
            return View();
        }
        public int comments(string username, string comments,string FeedBackRating)
        {
            //SqlConnection con = new SqlConnection(cs);
            //con.Open();
            //SqlCommand cmd = new SqlCommand("insert into Feedback(Username,FeedBackRating,Comments)values(@username,@FeedBackRating,@comments)", con);

            //cmd.Parameters.AddWithValue("@username", username);
            //cmd.Parameters.AddWithValue("@FeedBackRating", int.Parse(FeedBackRating));
            //cmd.Parameters.AddWithValue("@comments", comments);
            //int result = cmd.ExecuteNonQuery();
            //return result;



            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("UDP_InsertFeedback", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@FeedBackRating", int.Parse(FeedBackRating));
            cmd.Parameters.AddWithValue("@comments", comments);
            int result = cmd.ExecuteNonQuery();
            return result;
        }

    }
}
