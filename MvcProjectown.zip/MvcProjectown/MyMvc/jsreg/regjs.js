﻿$(document).ready(function () {
    $("#regsubmit").click(function () {
        var name = $("#name").val();
        var birthday = $("#birthday").val();
        var gender = $("#gender").val();

        alert(name + " " + birthday+"  " +gender);
    });

}
);


