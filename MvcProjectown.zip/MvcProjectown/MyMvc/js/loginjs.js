﻿$(document).ready(function () {
    $("#loginbutton").click(function () {
        var username = $("#username").val();
        var password = $("#password").val();
        alert(username + " " + password);
    });

}
);


